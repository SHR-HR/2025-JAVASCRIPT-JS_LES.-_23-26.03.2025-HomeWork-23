// Игра Змейка с новыми фичами: таймер, стены по сложности, корректный старт, улучшенное тач-управление
const canvas = document.getElementById("snake_game");
const ctx = canvas.getContext("2d");
const scoreDisplay = document.getElementById("score");
const bestScoreDisplay = document.getElementById("bestScore");
const gameOverScreen = document.getElementById("gameOver");
const restartBtn = document.getElementById("restartBtn");
const difficultySelect = document.getElementById("difficulty");
const skinSelect = document.getElementById("skin");
const wallToggle = document.getElementById("toggleWalls");
const playBtn = document.getElementById("playBtn");
const startScreen = document.getElementById("startScreen");

const size = 20;
let snake, apple, dx, dy, speed, score, gameInterval, wallBlocks;
let skinColor = "#00ff00";
let wallsEnabled = true;
let applePulse = 1;
let applePulseDir = 1;
let secondsElapsed = 0;
let timerInterval;
let appleTimer;
let appleTimeLeft = 10;

function setDifficulty(value) {
  if (value === "easy") return { speed: 200, walls: 5 };
  if (value === "medium") return { speed: 100, walls: 10 };
  if (value === "hard") return { speed: 60, walls: 20 };
  return { speed: 100, walls: 10 };
}

function initGame() {
  const diff = setDifficulty(difficultySelect.value);
  speed = diff.speed;
  snake = [{ x: 160, y: 160 }];
  dx = size;
  dy = 0;
  score = 0;
  secondsElapsed = 0;
  wallBlocks = generateWalls(diff.walls);
  apple = getRandomPosition();
  skinColor = skinSelect.value;
  applePulse = 1;

  scoreDisplay.textContent = "Очки: 0 | Время: 0с | Яблоко: 10с";
  bestScoreDisplay.textContent = `Рекорд: ${getBestScore()}`;
  gameOverScreen.classList.add("hidden");

  clearInterval(gameInterval);
  clearInterval(timerInterval);
  clearInterval(appleTimer);

  gameInterval = setInterval(gameLoop, speed);
  timerInterval = setInterval(() => {
    secondsElapsed++;
    updateScoreText();
  }, 1000);

  startAppleTimer();
}

function startAppleTimer() {
  clearInterval(appleTimer);
  appleTimeLeft = 10;

  appleTimer = setInterval(() => {
    appleTimeLeft--;
    updateScoreText();
    if (appleTimeLeft <= 0) {
      clearInterval(appleTimer);
      gameOver();
    }
  }, 1000);
}

function updateScoreText() {
  scoreDisplay.textContent = `Очки: ${score} | Время: ${secondsElapsed}с | Яблоко: ${appleTimeLeft}с`;
}

function getRandomPosition() {
  let pos;
  do {
    pos = {
      x: Math.floor(Math.random() * (canvas.width / size)) * size,
      y: Math.floor(Math.random() * (canvas.height / size)) * size,
    };
  } while (isWall(pos.x, pos.y));
  return pos;
}

function generateWalls(count) {
  if (!wallsEnabled) return [];
  let arr = [];
  for (let i = 0; i < count; i++) {
    let x = Math.floor(Math.random() * (canvas.width / size)) * size;
    let y = Math.floor(Math.random() * (canvas.height / size)) * size;
    arr.push({ x, y });
  }
  return arr;
}

function isWall(x, y) {
  return wallsEnabled && wallBlocks.some(w => w.x === x && w.y === y);
}

function gameLoop() {
  const head = { x: snake[0].x + dx, y: snake[0].y + dy };

  head.x = (head.x + canvas.width) % canvas.width;
  head.y = (head.y + canvas.height) % canvas.height;

  if (snake.some(s => s.x === head.x && s.y === head.y) || isWall(head.x, head.y)) {
    gameOver();
    return;
  }

  snake.unshift(head);

  if (head.x === apple.x && head.y === apple.y) {
    score++;
    updateBestScore(score);
    apple = getRandomPosition();
    startAppleTimer(); // Сбросить таймер на новое яблоко
  } else {
    snake.pop();
  }

  updateApplePulse();
  drawGame();
}

function updateApplePulse() {
  applePulse += 0.02 * applePulseDir;
  if (applePulse > 1.2 || applePulse < 0.8) applePulseDir *= -1;
}

function drawGame() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.save();
  ctx.translate(apple.x + size / 2, apple.y + size / 2);
  ctx.scale(applePulse, applePulse);
  ctx.fillStyle = "orange";
  ctx.fillRect(-size / 2 + 1, -size / 2 + 1, size - 2, size - 2);
  ctx.restore();

  if (wallsEnabled) {
    ctx.fillStyle = "#555";
    wallBlocks.forEach(w => ctx.fillRect(w.x, w.y, size - 2, size - 2));
  }

  snake.forEach((s, i) => {
    ctx.fillStyle = i % 2 === 0 ? skinColor : shadeColor(skinColor, -30);
    ctx.fillRect(s.x, s.y, size - 2, size - 2);
  });
}

function shadeColor(c, percent) {
  let f = parseInt(c.slice(1), 16), t = percent < 0 ? 0 : 255, p = Math.abs(percent),
      R = f >> 16, G = f >> 8 & 0x00FF, B = f & 0x0000FF;
  return "#" + (
    0x1000000 +
    (Math.round((t - R) * p) + R) * 0x10000 +
    (Math.round((t - G) * p) + G) * 0x100 +
    (Math.round((t - B) * p) + B)
  ).toString(16).slice(1);
}

function gameOver() {
  clearInterval(gameInterval);
  clearInterval(timerInterval);
  clearInterval(appleTimer);
  gameOverScreen.classList.remove("hidden");
}

function updateBestScore(score) {
  const best = getBestScore();
  if (score > best) {
    localStorage.setItem("best_score", score);
    bestScoreDisplay.textContent = `Рекорд: ${score}`;
  }
}

function getBestScore() {
  return +localStorage.getItem("best_score") || 0;
}

document.addEventListener("keydown", e => {
  if ((e.key === "ArrowLeft" || e.key === "a") && dx === 0) { dx = -size; dy = 0; }
  else if ((e.key === "ArrowRight" || e.key === "d") && dx === 0) { dx = size; dy = 0; }
  else if ((e.key === "ArrowUp" || e.key === "w") && dy === 0) { dx = 0; dy = -size; }
  else if ((e.key === "ArrowDown" || e.key === "s") && dy === 0) { dx = 0; dy = size; }
});

document.getElementById("touchControls").addEventListener("click", e => {
  const dir = e.target.dataset.dir;
  if (dir === "left" && dx === 0) { dx = -size; dy = 0; }
  else if (dir === "right" && dx === 0) { dx = size; dy = 0; }
  else if (dir === "up" && dy === 0) { dx = 0; dy = -size; }
  else if (dir === "down" && dy === 0) { dx = 0; dy = size; }
});

restartBtn.addEventListener("click", initGame);
skinSelect.addEventListener("change", () => skinColor = skinSelect.value);
wallToggle.addEventListener("change", () => {
  wallsEnabled = wallToggle.checked;
  initGame();
});
playBtn.addEventListener("click", () => {
  if (!difficultySelect.value) return alert("Выберите уровень сложности");
  startScreen.classList.add("hidden");
  document.getElementById("ui").classList.remove("hidden");
  initGame();
});

